﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.Practices.Unity.TestSupport
{
    public partial class Wrappable : MarshalByRefObject
    {
    }

    public partial class WrappableWithProperty : MarshalByRefObject
    {

    }    
}
